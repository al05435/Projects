import csv
from tree import Node
covidDataNodes = []
with open("covid-data.csv", 'r') as file:
    csv_file = csv.reader(file)
    for row in csv_file:
        # covidRow = Node(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7])
        covidDataNodes.append(row)

# print(covidDataNodes[1].country)




